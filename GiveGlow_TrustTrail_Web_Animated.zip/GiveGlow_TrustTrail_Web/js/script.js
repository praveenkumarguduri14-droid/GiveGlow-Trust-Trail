const money = n => "₹" + Number(n).toLocaleString("en-IN");
const $ = s => document.querySelector(s);
const NAV = ["Home","Explore Causes","Impact Reports","My Dashboard","About Trust"];
const CATS = ["All causes","Child Education","Disaster Relief","Animal Welfare","Rural Healthcare"];
const S = { campaigns: initialCampaigns.map(c => ({...c})), active:"Home", query:"", category:"All causes", donations:[], notice:"", selected:null };

try{const sv=JSON.parse(localStorage.getItem("giveglow")||"null");if(sv){S.donations=sv.donations||[];S.campaigns.forEach(c=>{const x=sv.campaigns?.[c.id];if(x){c.raised=x.raised;c.donors=x.donors}})}}catch(e){}
function save(){try{localStorage.setItem("giveglow",JSON.stringify({donations:S.donations,campaigns:Object.fromEntries(S.campaigns.map(c=>[c.id,{raised:c.raised,donors:c.donors}]))}))}catch(e){}}

function go(page){ S.active = page; $("#mobilenav").classList.remove("open"); render(); window.scrollTo(0,0); }
function scrollToCampaigns(){ $("#campaigns")?.scrollIntoView({behavior:"smooth"}); }

function renderNav(){
  $("#navwrap").innerHTML = `<button class="brand" data-go="Home"><span class="brandmark">♥</span><span>GiveGlow<small>TRUSTTRAIL</small></span></button>
  <nav>${NAV.map(n=>`<button class="navlink ${S.active===n?"active":""}" data-go="${n}">${n}</button>`).join("")}</nav>
  <button class="donate-nav" data-scroll>Donate now →</button>
  <button class="mobile-menu" data-menu>☰</button>`;
  $("#mobilenav").innerHTML = NAV.map(n=>`<button data-go="${n}">${n}</button>`).join("");
}
function renderNotice(){
  $("#notice").innerHTML = S.notice ? `<div class="notice">✔ ${S.notice}<button data-clear>✕</button></div>` : "";
}
const filtered = () => S.campaigns.filter(c => (S.category==="All causes"||c.category===S.category) && c.title.toLowerCase().includes(S.query.toLowerCase()));

function grid(list){
  return `<div class="campaign-grid">${list.map(c=>`<article class="campaign-card">
    <div class="campaign-image"><img src="${c.image}" alt="${c.title}"><span>${c.tag}</span></div>
    <div class="campaign-body"><div class="category">${c.category}</div><h3>${c.title}</h3><p>${c.impact}</p>
    <div class="progress-label"><b>${money(c.raised)}</b><span>of ${money(c.goal)}</span></div>
    <div class="progress"><i style="width:${Math.min(100,c.raised/c.goal*100)}%"></i></div>
    <div class="card-foot"><span>👥 ${c.donors} donors</span><span>⏳ ${META[c.id].deadline}</span><b>${Math.round(c.raised/c.goal*100)}% funded</b></div>
    <button class="card-donate" data-donate="${c.id}">Support this cause →</button></div></article>`).join("")}</div>`;
}
const ledger = () => `<section class="ledger-section"><div class="ledger-inner"><div><div class="eyebrow">FOLLOW THE FUNDS</div><h2>Clarity in every <em>rupee.</em></h2><p>Our sample allocation model makes the intended use of every contribution easy to understand.</p>
  <div class="ledger-rows"><div><span class="swatch green"></span><b>Field goods</b><strong>85%</strong><small>₹850 of every ₹1,000</small></div><div><span class="swatch gold"></span><b>Logistics</b><strong>10%</strong><small>₹100 of every ₹1,000</small></div><div><span class="swatch grey"></span><b>Administration</b><strong>5%</strong><small>₹50 of every ₹1,000</small></div></div>
  <div class="stack" role="img" aria-label="Field goods 85%, Logistics 10%, Administration 5%"><i class="swatch green" style="width:85%"></i><i class="swatch gold" style="width:10%"></i><i class="swatch grey" style="width:5%"></i></div>
  <details class="alloc"><summary>Itemized ledger per campaign</summary><table><tr><th>Campaign</th><th>Raised</th><th>Field goods</th><th>Logistics</th><th>Admin</th></tr>${S.campaigns.map(c=>`<tr><td>${c.title}</td><td>${money(c.raised)}</td><td>${money(c.raised*.85)}</td><td>${money(c.raised*.10)}</td><td>${money(c.raised*.05)}</td></tr>`).join("")}</table></details>
  <small class="fineprint">Illustrative allocation only. Actual campaign expenditure must be supported by audited records.</small></div>
  <div class="donut-wrap"><div class="donut"><div><b>100%</b><span>of funds allocated</span></div></div><div class="donut-label">Transparent fund allocation</div></div></div></section>`;

const views = {
  "Home": () => `<section class="hero"><div class="hero-copy"><div class="eyebrow">TRANSPARENCY YOU CAN TRACE</div><h1>Every rupee.<br><em>Every impact.</em><br>Every proof.</h1><p>Give with confidence. Follow your contribution from the moment it is donated to the moment it changes a life.</p>
    <div class="hero-actions"><button class="primary" data-go="Explore Causes">Explore campaigns →</button><button class="text-btn" data-go="Impact Reports">See impact reports →</button></div>
    <div class="trust-note">Transparent allocation · Documented milestones · Donor-first reporting</div></div>
    <div class="hero-visual"><img src="https://images.unsplash.com/photo-1488521787991-ed7bbaae773c?w=1200" alt="Children learning together"><div class="floating-card"><span class="float-icon">🤲</span><div><b>Every contribution counts</b><small>Track the difference you make.</small></div></div><div class="image-caption">HOPE, MADE VISIBLE <span>01 / 04</span></div></div></section>
    <section class="stats"><div><span>Total campaign funds raised</span><b>${money(S.campaigns.reduce((s,c)=>s+c.raised,0))}</b><small>Across 6 demo campaigns</small></div><div><span>Campaigns</span><b>06</b><small>Across 4 cause categories</small></div><div><span>Fund allocation to field goods</span><b>85%</b><small>Illustrative allocation model</small></div><div><span>Impact updates</span><b>03</b><small>Sample milestone reports</small></div></section>
    <section class="section" id="campaigns"><div class="section-heading"><div><div class="eyebrow">MAKE A DIFFERENCE</div><h2>Causes worth <em>believing in.</em></h2><p>Explore campaigns, understand their goals and choose where your support matters most.</p></div><button class="outline" data-go="Explore Causes">View all causes →</button></div>${grid(S.campaigns.slice(0,3))}</section>
    ${ledger()}<section class="quote"><h2>Trust isn't promised.<br><em>It's demonstrated.</em></h2><p>We believe every donor deserves to know what happened after they gave.</p><button class="light-btn" data-go="Impact Reports">Explore impact reports →</button></section>`,

  "Explore Causes": () => `<section class="section page-section" id="campaigns"><div class="eyebrow">CAMPAIGN DIRECTORY</div><h2>Find a cause. <em>Fuel a change.</em></h2><p class="section-intro">Browse sample campaigns and see how every contribution can create measurable impact.</p>
    <div class="filters"><div class="searchbox">🔍<input id="search" value="${S.query}" placeholder="Search campaigns"></div><select id="cat">${CATS.map(x=>`<option ${x===S.category?"selected":""}>${x}</option>`).join("")}</select></div><div id="grid">${grid(filtered())}</div></section>`,

  "Impact Reports": () => `<section class="section page-section"><div class="eyebrow">PROOF ON THE GROUND</div><h2>Impact you can <em>see.</em></h2><p class="section-intro">A chronological sample of delivery updates. These images and reports are illustrative demo content, not independently verified field evidence.</p>
    <div class="timeline">${milestones.map((m,i)=>`<article class="milestone"><div class="timeline-dot">${i+1}</div><img src="${m.image}" alt="${m.title}"><div class="milestone-copy"><div class="milestone-meta"><span>📅 ${m.date}</span><span>📍 ${m.place}</span></div><h3>${m.title}</h3><p>${m.detail}</p><div class="recipient">👥 <b>${m.count}</b><span>reported in sample update</span></div><div class="verified">Demo milestone · Verification pending</div></div></article>`).join("")}</div></section>`,

  "My Dashboard": () => {
    const d = S.donations, total = d.reduce((s,x)=>s+x.amount,0);
    return `<section class="section page-section"><div class="eyebrow">YOUR GIVING JOURNEY</div><h2>Your impact, <em>in one place.</em></h2><p class="section-intro">Your personal donor portfolio saved in this browser (localStorage).</p>
    <div class="dashboard-stats"><div><span>Total contributed</span><b>${money(total)}</b><small>Recorded demo donations</small></div><div><span>Causes supported</span><b>${new Set(d.map(x=>x.campaign)).size}</b><small>Unique campaigns</small></div><div><span>Lives / units impacted</span><b>${d.reduce((s,x)=>s+(x.units||0),0)}</b><small>Cumulative, per campaign unit cost</small></div></div>
    ${d.length?`<button class="outline" data-badge>Download social badge card ⬇</button>`:""}<div class="ledger-table"><div class="table-title"><h3>Donation history</h3><span>${d.length} records</span></div>
    ${d.length===0?`<div class="empty"><b>Your giving story starts here.</b><p>Choose a campaign and make your first demo contribution.</p><button class="primary" data-go="Explore Causes">Explore causes →</button></div>`
    :d.map(x=>`<div class="donation-row"><div><b>${x.campaign}</b><small>${x.date} · ${x.id}</small></div><strong>${money(x.amount)}</strong><button class="icon-btn" title="Open 80G receipt" data-receipt="${x.id}">⬇</button></div>`).join("")}</div></section>`;
  },

  "About Trust": () => `<section class="section page-section"><div class="eyebrow">OUR PROMISE</div><h2>Giving deserves <em>accountability.</em></h2><p class="section-intro">GiveGlow TrustTrail is a hackathon demonstration concept designed to make charitable giving easier to understand and track.</p>
    <div class="about-grid"><div><h3>Transparent allocation</h3><p>Show a clear illustrative split of campaign funds into field goods, logistics and administration.</p></div><div><h3>Itemized impact</h3><p>Connect donation amounts with tangible goods and service equivalents.</p></div><div><h3>Evidence-led updates</h3><p>Publish dated reports with beneficiary counts and supporting documentation.</p></div></div>
    <div class="disclaimer"><b>Important demo disclosure</b><p>All campaign amounts, NGOs, donor records, impact reports, photographs and payment flows in this project are sample data. No real payment is processed. No NGO or milestone is verified by this prototype. The downloadable receipt is not a legally valid 80G certificate.</p></div></section>`
};

function render(){ renderNav(); renderNotice(); $("#view").innerHTML = views[S.active](); }

/* ---------- Donation modal ---------- */
const impactText = (c, a) => {
  const m = META[c.id], n = Math.floor(Number(a||0) / m.unit);
  const label = m.labels?.[a] || (n ? `${n} ${m.name}${n>1?"s":""}` : "");
  return label ? `Your ${money(a)} provides <b>${label}</b>.` : `Donate at least <b>${money(m.unit)}</b> to fund 1 ${m.name}.`;
};
function openDonate(id){
  const c = S.campaigns.find(x => x.id == id), m = META[id]; S.selected = c;
  const first = m.tiers[2] || m.tiers[0];
  $("#modal").innerHTML = `<div class="modal-backdrop" id="backdrop"><form class="donation-modal" id="donform"><button type="button" class="modal-close" data-close aria-label="Close">✕</button>
  <div class="eyebrow">MAKE A CONTRIBUTION</div><h2>Support <em>${c.title}</em></h2><p class="modal-impact">${c.impact}</p>
  <label>Choose your donation</label><div class="amounts">${m.tiers.map(a=>`<button type="button" class="amount ${a===first?"active":""}" data-amt="${a}">${money(a)}<small>${m.labels?.[a] || Math.floor(a/m.unit)+" × "+m.name}</small></button>`).join("")}</div>
  <label for="custom">Custom amount (₹)</label><input id="custom" type="number" min="1" value="${first}" required>
  <div class="impact-preview">✨ <span id="units">${impactText(c, first)}</span></div>
  <div class="form-grid"><div><label for="dname">Your name</label><input id="dname" required placeholder="Full name"></div><div><label for="demail">Email address</label><input id="demail" required type="email" placeholder="you@example.com"></div>
  <div class="full"><label for="dpan">PAN (for 80G receipt)</label><input id="dpan" placeholder="ABCDE1234F" maxlength="10"></div>
  <div class="full"><label for="dpay">Demo payment method</label><select id="dpay"><option>Demo UPI</option><option>Demo NetBanking</option><option>Demo Credit Card</option></select></div></div>
  <p class="form-error" id="ferr"></p><button class="primary submit" type="submit">Confirm demo donation →</button><small class="legal-note">Simulation only. No money will be charged.</small></form></div>`;
}
function closeModal(){ $("#modal").innerHTML = ""; S.selected = null; }
function syncAmount(v){
  $("#custom").value = v; $("#units").innerHTML = impactText(S.selected, Number(v));
  document.querySelectorAll(".amount").forEach(b => b.classList.toggle("active", Number(b.dataset.amt) === Number(v)));
}
function completeDonation(e){
  e.preventDefault();
  const amount = Number($("#custom").value), c = S.selected, pan = $("#dpan").value.toUpperCase().trim();
  if (pan && !/^[A-Z]{5}[0-9]{4}[A-Z]$/.test(pan)) { $("#ferr").textContent = "PAN format should be like ABCDE1234F."; return; }
  const units = Math.floor(amount / META[c.id].unit);
  S.donations.unshift({ id:"GG-"+Date.now().toString().slice(-8), name:$("#dname").value, email:$("#demail").value, pan, amount, units, campaign:c.title, unitName:META[c.id].name, date:new Date().toLocaleDateString("en-IN"), payment:$("#dpay").value });
  c.raised += amount; c.donors += 1; save();
  closeModal(); S.notice = "Thank you! Your demo donation was recorded and your receipt is ready in the dashboard."; go("My Dashboard");
}

/* ---------- Amount in words (Indian numbering) ---------- */
function words(n){
  const a=["","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"],
        t=["","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"];
  const two = x => x<20 ? a[x] : t[Math.floor(x/10)] + (x%10 ? " "+a[x%10] : "");
  const part = (x, name) => x ? two(x) + " " + name + " " : "";
  return (part(Math.floor(n/1e7), "Crore") + part(Math.floor(n/1e5)%100, "Lakh") + part(Math.floor(n/1e3)%100, "Thousand") + part(Math.floor(n/100)%10, "Hundred") + (n%100 ? (n>100?"and ":"") + two(n%100) + " " : "")).trim() + " Rupees Only";
}

/* ---------- 80G-style receipt (opens in a new tab; use Print > Save as PDF) ---------- */
function openReceipt(d){
  const ref = `80G/DEMO/2026-27/${d.id}`;
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Receipt ${d.id}</title><style>
  body{font-family:Georgia,serif;max-width:720px;margin:30px auto;padding:30px;border:2px solid #174d3a;color:#202923}
  h1{color:#174d3a;margin:0}table{width:100%;border-collapse:collapse;margin:18px 0}td{padding:8px;border-bottom:1px solid #ddd}td:first-child{color:#666;width:38%}
  .demo{background:#fff4d6;border:1px solid #e0b84d;padding:10px;font:13px sans-serif}.btn{padding:10px 18px;background:#174d3a;color:#fff;border:0;border-radius:6px;cursor:pointer}
  @media print{.btn{display:none}}</style></head><body>
  <h1>${NGO.name}</h1><p>${NGO.address}<br>Registration No.: ${NGO.reg} · NGO PAN: ${NGO.pan}</p>
  <h2>Donation Receipt — Section 80G</h2>
  <table><tr><td>Receipt No.</td><td>${d.id}</td></tr><tr><td>80G Reference No.</td><td>${ref}</td></tr><tr><td>Date</td><td>${d.date}</td></tr>
  <tr><td>Donor name</td><td>${d.name}</td></tr><tr><td>Donor email</td><td>${d.email}</td></tr><tr><td>Donor PAN</td><td>${d.pan || "Not provided"}</td></tr>
  <tr><td>Campaign</td><td>${d.campaign}</td></tr><tr><td>Amount</td><td><b>${money(d.amount)}</b></td></tr><tr><td>Amount in words</td><td>${words(d.amount)}</td></tr>
  <tr><td>Payment mode</td><td>${d.payment}</td></tr></table>
  <p>Donations to this organisation are eligible for deduction under Section 80G of the Income-tax Act, 1961, subject to the organisation's valid approval and applicable limits.</p>
  <div class="demo"><b>DEMO ONLY:</b> All registration numbers are sample values and no money was transferred. This is not a valid tax certificate.</div>
  <p><button class="btn" onclick="window.print()">Print / Save as PDF</button></p></body></html>`;
  window.open(URL.createObjectURL(new Blob([html], {type:"text/html"})), "_blank");
}

/* ---------- Social badge story card (stretch feature, drawn on canvas) ---------- */
function downloadBadge(){
  const total = S.donations.reduce((s,x)=>s+x.amount,0), lives = S.donations.reduce((s,x)=>s+x.units,0);
  const c = document.createElement("canvas"); c.width = 1080; c.height = 1920; const g = c.getContext("2d");
  const grad = g.createLinearGradient(0,0,0,1920); grad.addColorStop(0,"#174d3a"); grad.addColorStop(1,"#0b2a20");
  g.fillStyle = grad; g.fillRect(0,0,1080,1920); g.fillStyle = "#f4d58d"; g.textAlign = "center";
  g.font = "bold 120px Georgia"; g.fillText("♥", 540, 500);
  g.fillStyle = "#fff"; g.font = "bold 80px Georgia"; g.fillText("I gave with GiveGlow", 540, 700);
  g.font = "bold 150px Georgia"; g.fillStyle = "#f4d58d"; g.fillText(money(total), 540, 950);
  g.fillStyle = "#fff"; g.font = "52px Georgia"; g.fillText(`${lives} impact units · ${new Set(S.donations.map(x=>x.campaign)).size} causes`, 540, 1080);
  g.font = "40px Georgia"; g.fillText("Every Rupee. Every Impact. Every Proof.", 540, 1700);
  const a = document.createElement("a"); a.href = c.toDataURL("image/png"); a.download = "GiveGlow-badge.png"; a.click();
}

/* ---------- Events ---------- */
document.addEventListener("click", e => {
  const t = e.target.closest("[data-go],[data-donate],[data-receipt],[data-amt],[data-close],[data-scroll],[data-menu],[data-clear],[data-badge]");
  if (e.target.id === "backdrop") return closeModal();
  if (!t) return;
  const d = t.dataset;
  if (d.go) { go(d.go); if (d.go === "Explore Causes") S.notice = ""; }
  else if (d.donate) openDonate(d.donate);
  else if (d.receipt) openReceipt(S.donations.find(x => x.id === d.receipt));
  else if (d.amt) syncAmount(d.amt);
  else if (t.hasAttribute("data-close")) closeModal();
  else if (t.hasAttribute("data-scroll")) { if (S.active !== "Home") go("Home"); scrollToCampaigns(); }
  else if (t.hasAttribute("data-menu")) $("#mobilenav").classList.toggle("open");
  else if (t.hasAttribute("data-badge")) downloadBadge();
  else if (t.hasAttribute("data-clear")) { S.notice = ""; renderNotice(); }
});
document.addEventListener("input", e => {
  if (e.target.id === "search") { S.query = e.target.value; $("#grid").innerHTML = grid(filtered()); }
  if (e.target.id === "custom") syncAmount(e.target.value);
});
document.addEventListener("change", e => { if (e.target.id === "cat") { S.category = e.target.value; $("#grid").innerHTML = grid(filtered()); } });
document.addEventListener("submit", e => { if (e.target.id === "donform") completeDonation(e); });

render();

/* ---------- Animation helpers: scroll reveal + count-up ---------- */
(function () {
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const io = "IntersectionObserver" in window ? new IntersectionObserver(entries => {
    entries.forEach(en => { if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); } });
  }, { threshold: .15 }) : null;

  function countUp(el) {
    const txt = el.textContent.trim();
    const m = txt.match(/^(\D*)([\d,]+(?:\.\d+)?)(.*)$/);
    if (!m) return;
    const pre = m[1], raw = m[2], suf = m[3], to = parseFloat(raw.replace(/,/g, ""));
    const dec = (raw.split(".")[1] || "").length, lead0 = /^0\d/.test(raw), width = raw.length;
    const fmt = v => {
      let s = dec ? v.toFixed(dec) : String(Math.round(v));
      if (lead0) s = s.padStart(width, "0");
      else if (raw.includes(",")) s = Number(s).toLocaleString("en-IN", { minimumFractionDigits: dec, maximumFractionDigits: dec });
      return pre + s + suf;
    };
    const t0 = performance.now(), dur = 1400;
    (function step(t) {
      const p = Math.min(1, (t - t0) / dur), e = 1 - Math.pow(1 - p, 3);
      el.textContent = fmt(to * e);
      if (p < 1) requestAnimationFrame(step); else el.textContent = txt;
    })(t0);
  }

  function enhance() {
    document.querySelectorAll(".stats div,.ledger-section .ledger-inner>div,.quote,.section-heading").forEach(n => {
      if (n.dataset.fx) return; n.dataset.fx = 1;
      if (reduce || !io) return; n.classList.add("reveal"); io.observe(n);
    });
    if (!reduce) document.querySelectorAll(".stats b,.dashboard-stats b").forEach(b => {
      if (b.dataset.cnt) return; b.dataset.cnt = 1;
      const obs = new IntersectionObserver((es, o) => es.forEach(e => { if (e.isIntersecting) { countUp(b); o.disconnect(); } }), { threshold: .4 });
      obs.observe(b);
    });
  }
  new MutationObserver(enhance).observe(document.getElementById("view"), { childList: true });
  enhance();
})();
