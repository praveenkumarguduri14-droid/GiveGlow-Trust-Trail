const initialCampaigns = [
  {id:1,title:"Mid-Day Meals for Children",category:"Child Education",raised:370000,goal:500000,donors:284,image:"https://images.unsplash.com/photo-1509099836639-18ba1795216d?w=900",impact:"₹500 provides a nutritious meal kit for a child.",tag:"Most supported"},
  {id:2,title:"Flood Relief Care Packages",category:"Disaster Relief",raised:240000,goal:400000,donors:196,image:"https://images.unsplash.com/photo-1547683905-f686c993fde9?w=900",impact:"₹1,000 helps provide essential emergency supplies.",tag:"Urgent"},
  {id:3,title:"Stray Animal Vaccination",category:"Animal Welfare",raised:180000,goal:300000,donors:142,image:"https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=900",impact:"₹750 supports vaccination and basic care.",tag:"Community care"},
  {id:4,title:"Rural Girl STEM Education Drive",category:"Child Education",raised:370000,goal:500000,donors:318,image:"https://images.unsplash.com/photo-1509062522246-3755977927d7?w=900",impact:"₹1,500 sponsors science kits for 3 girls.",tag:"Featured"},
  {id:5,title:"Rural Healthcare Mission",category:"Rural Healthcare",raised:210000,goal:350000,donors:167,image:"https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=900",impact:"₹2,000 helps support a rural health camp.",tag:"Health"},
  {id:6,title:"Clean Water for Villages",category:"Rural Healthcare",raised:300000,goal:400000,donors:231,image:"https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=900",impact:"₹1,000 contributes to safe-water access.",tag:"Long-term impact"}
];
const milestones = [
  {date:"12 Nov 2026",place:"Warangal, Telangana",title:"Science kits delivered to rural students",count:"120 students",image:"https://images.unsplash.com/photo-1509062522246-3755977927d7?w=900",detail:"Learning kits containing basic experiment tools and workbooks."},
  {date:"08 Nov 2026",place:"Hyderabad, Telangana",title:"Community meal distribution completed",count:"350 meal kits",image:"https://images.unsplash.com/photo-1593113598332-cd288d649433?w=900",detail:"Nutritious meal kits distributed through the local partner team."},
  {date:"02 Nov 2026",place:"Khammam, Telangana",title:"Emergency relief packages handed over",count:"85 families",image:"https://images.unsplash.com/photo-1469571486292-0ba58a3f068b?w=900",detail:"Dry ration, hygiene supplies and clean drinking water."}
];

/* Per-campaign extras: deadline, cost of one impact unit, unit name, NGO details (all SAMPLE data) */
const D = [500,1000,1500,2500,5000];
const META = {
  1:{deadline:"31 Dec 2026",unit:500,name:"Mid-Day Meal Kit",tiers:D,labels:{2500:"1 Year School Bag & Uniform"}},
  2:{deadline:"15 Dec 2026",unit:1000,name:"Emergency Care Package",tiers:[1000,2000,3000,5000,10000]},
  3:{deadline:"20 Jan 2027",unit:750,name:"Vaccination Dose",tiers:[750,1500,3000,5000]},
  4:{deadline:"28 Feb 2027",unit:500,name:"Science Kit",tiers:D,labels:{1500:"Science Kits for 3 Girls"}},
  5:{deadline:"31 Jan 2027",unit:500,name:"Basic Health Check-up",tiers:D},
  6:{deadline:"31 Mar 2027",unit:1000,name:"Family Safe-Water Kit",tiers:[1000,2000,3000,5000,10000]}
};
const NGO = {name:"Sample Hope Foundation (DEMO)",reg:"DEMO/REG/0000/2026",pan:"AAAAA0000A",address:"Sample Address, Hyderabad, Telangana 500001"};
